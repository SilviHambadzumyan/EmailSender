var logpass =  [
  { 
    email: "silvihambardzumyan1999@gmail.com",
    lock: "123456"
  }
]

function getInfo() {
  var email = document.getElementById("email").value
  var lock = document.getElementById("lock").value

  console.log("correct")
}
